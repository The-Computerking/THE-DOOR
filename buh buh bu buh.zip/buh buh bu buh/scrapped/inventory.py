inventoryitems = []
armourslot = " "
weponsslot = ""