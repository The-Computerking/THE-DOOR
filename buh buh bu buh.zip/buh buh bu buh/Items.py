from rn import ranum
from rn import ranum2
from rn import ranum3
from rn import dungeonchest1
items = ["a sword", "a mace", "an axe", "a spear", "bread", "an apple", "a cookie", "iron armour", "leather armour", "diamond armour"]
chestia = items[ranum]
chestia2 = items[ranum2]
chestia3 = items[ranum3]
dungeonchestone = items[dungeonchest1]