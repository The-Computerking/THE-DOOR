skin = ["scaly", "furry", "smooth", "rough"]
teeth = ["sharp", "smooth", "no", "sharp fangs"]
claws = ["long", "short", "big", "small"]
clawsharpness = ["sharp", "blunt"]
