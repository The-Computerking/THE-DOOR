from random import randint

doorhealthrandom = randint(1, 10)
skinrandom = randint(0, 3)
clawrandom = randint(0, 3)
clawsharpnessrandom = randint(0, 1)
creaturerandom = randint(1, 20)
doorone = randint(0, 2)
randomenenimetotal = randint(1, 3)
# chests
ranum = randint(0, 9)
ranum2 = randint(0, 9)
ranum3 = randint(0, 9)
# dungeon chests
dungeonchest1 = randint(0, 9)